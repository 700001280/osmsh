package com.osmsh.site;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OsmshApplication {

	public static void main(String[] args) {
		SpringApplication.run(OsmshApplication.class, args);
	}	

}
